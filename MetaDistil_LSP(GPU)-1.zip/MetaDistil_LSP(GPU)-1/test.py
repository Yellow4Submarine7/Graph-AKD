import os
import copy 
import numpy as np
import torch
import torch.nn.functional as F
import dgl.function as fn
from torch.nn import init
import dgl
import argparse
from gat import GAT
from torch.utils.data import DataLoader
from dgl.data.ppi import LegacyPPIDataset as PPIDataset

def collate(sample):
    graphs, feats, labels =map(list, zip(*sample))
    graph = dgl.batch(graphs)
    feats = torch.from_numpy(np.concatenate(feats))
    labels = torch.from_numpy(np.concatenate(labels))
    return graph, feats, labels

def get_data_loader(batch_size):
    '''create the dataset
    return 
        three dataloders and data_info
    '''
    train_dataset = PPIDataset(mode='train')
    valid_dataset = PPIDataset(mode='valid')
    test_dataset = PPIDataset(mode='test')
    train_support_dataset = PPIDataset(mode='train_support')
    train_query_dataset = PPIDataset(mode='train_query')


    train_dataloader = DataLoader(train_dataset, batch_size=batch_size, collate_fn=collate, num_workers=0, shuffle=True)
    fixed_train_dataloader = DataLoader(train_dataset, batch_size=batch_size, collate_fn=collate, num_workers=0)
    train_support_dataloader = DataLoader(train_support_dataset, batch_size=batch_size, collate_fn=collate, num_workers=0, shuffle=True)
    train_query_dataloader = DataLoader(train_query_dataset, batch_size=batch_size, collate_fn=collate, num_workers=0, shuffle=True)
    
    valid_dataloader = DataLoader(valid_dataset, batch_size=batch_size, collate_fn=collate, num_workers=0)
    test_dataloader = DataLoader(test_dataset, batch_size=batch_size, collate_fn=collate, num_workers=0)

    n_classes = test_dataset._labels.shape[1]
    num_feats = train_dataset._feats.shape[1]
    g = train_dataset.graph
    data_info = {}
    data_info['n_classes'] = n_classes
    data_info['num_feats'] = num_feats
    data_info['g'] = g
    return (train_dataloader, train_support_dataloader, train_query_dataloader, valid_dataloader, test_dataloader, fixed_train_dataloader), data_info

data, data_info = get_data_loader(2)
train_dataloader, train_support_dataloader, train_query_dataloader,valid_dataloader, test_dataloader, fixed_train_dataloader = data

for batch, batch_data in enumerate(train_support_dataloader):
    # support_iter = iter(train_support_dataloader)
    # support_batch = support_iter.next()
    # subgraph, feats, labels = support_batch
    # print(subgraph)
    
    shuffle_data = batch_data
    subgraph, feats, labels = shuffle_data
    print(labels.size())
