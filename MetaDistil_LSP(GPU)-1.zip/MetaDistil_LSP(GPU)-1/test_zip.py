A = [1,2,3,4,5,6,7]
B = [8,6,5,4,3,2,1]

for a,b in enumerate(zip(A,B)):
    print(a,b)
    print(a)
    print(b)
