support_dataset = [1,2,3,4,5]
query_dataset = [6,7]

#for num,support_data in enumerate(support_dataset):

print(enumerate(support_dataset))
