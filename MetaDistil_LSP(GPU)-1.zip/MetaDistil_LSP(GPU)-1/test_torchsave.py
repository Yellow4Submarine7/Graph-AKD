import torch
t0_model = torch.load("/Users/brownjack/Desktop/备份/文件/dp/Graph-distil/masters/Alignahead-main/a04.pkl")
print(t0_model)