#newview版Meta_distill的第二步是不变的
import os
import copy 
import numpy as np
import torch
import torch.nn.functional as F
import dgl.function as fn
from torch.nn import init
import dgl
import argparse
from gat import GAT
from utils import get_data_loader, evaluate_model, test_model
from get_models import collect_model
from plot_utils import loss_logger, parameters
import time

import matplotlib.pyplot as plt
import collections
import random

torch.set_num_threads(1)   

def graph_KLDiv(graph, edgex, edgey, reduce='mean'):
    ''' 计算每个edges set的KL散度, 在edge_softmax之后用, 这样都在0-1之间才是概率 '''
    with graph.local_scope():   #????graph 的结构是在哪里定义的 DGL里面
        nnode = graph.number_of_nodes()
        #ndata = node features
        #graph.ndata.updata({'kldiv': torch.ones(nnode,1).to(edgex.device)})#ndata=node features
        graph.ndata.update({'kldiv': torch.ones(nnode,1).to(edgex.device)})
        diff = edgey*(torch.log(edgey)-torch.log(edgex))#y是真实分布，x是预测分布
        graph.edata.update({'diff':diff}) #edata就是edge features
        '''dgl.funcion.u_mul_e() 在DGL中表示用源节点乘边 '''
        graph.update_all(fn.u_mul_e('kldiv', 'diff', 'm'),
                            fn.sum('m', 'kldiv'))
        if reduce == "mean": #取所有KL散度的平均值
            return torch.mean(torch.flatten(graph.ndata['kldiv']))

def train_student(args, auxiliary_model, data, device):
    '''
    策略集:
        alignahead: 循环学习
        OC: one-to-one: 对齐的
        Meta: Meta-learning
    '''

    best_score = np.zeros(args.model_num)
    best_loss = 1000.0*np.ones(args.model_num)
    test_score = np.zeros(args.model_num)

    train_dataloader, train_support_dataloader, train_query_dataloader,valid_dataloader, test_dataloader, fixed_train_dataloader = data

    #class loss可以使用多种
    loss_fcn = torch.nn.BCEWithLogitsLoss()
    loss_mse = torch.nn.MSELoss()
    loss_bce = torch.nn.BCELoss()

    #Meta KD 
    #主要逻辑部分

    #获取model_list[] 这是一个模型的列表，里面有几个model_num，就有几个模型，都是同种模型，三选一
    model_list = auxiliary_model['s_model']['model']
    optimizer_list = auxiliary_model['s_model']['optimizer']

    losslogger = loss_logger()

    for epoch in range(args.s_epochs):
        #每个epoch中三个模型每个模型分别尝试一次
        for model_id in range(args.model_num):
            torch.autograd.set_detect_anomaly(True)
            loss_list = []
            s_lsp_loss_list = []

            #目前t_model和s_model相同
            t_model = model_list[model_id]
            t_optimizer = optimizer_list[model_id]
            s_model = model_list[model_id]
            s_optimizer = optimizer_list[model_id]

            t0 = time.time()

            for batch, batch_data in enumerate(train_support_dataloader):
                t_model.train()
                s_model.train()

                """
                以下部分先处理LSP_Meta_distill
                """

                "需要把support_batch和query_batch同时取出来,用enumerate逻辑不对,用iter"
                try:
                    support_batch = support_iter.__next__()
                    support_subgraph, support_feats, support_labels = support_batch

                except:
                    support_iter = iter(train_support_dataloader)
                    support_batch = support_iter.__next__()
                    support_subgraph, support_feats, support_labels = support_batch
                
                support_feats = support_feats.to(device)
                support_labels = support_labels.to(device)
                support_subgraph = support_subgraph.to(device)


                try:
                    query_batch = support_iter.__next__()
                    query_subgraph, query_feats, query_labels = query_batch
                except:
                    query_iter = iter(train_query_dataloader)
                    query_batch = query_iter.__next__()
                    query_subgraph, query_feats, query_labels = query_batch

                query_feats = query_feats.to(device)
                query_labels = query_labels.to(device)
                query_subgraph = query_subgraph.to(device)
                
                #每次都要把数据集内取到的图片集作为子图传入模型，不然和取到的feats不能对应起来了
                #with torch.no_grad():
                s_model.g = support_subgraph
                for layer in s_model.gat_layers:
                    layer.g = support_subgraph
                _, s_middlefeats_support = s_model(support_feats.float(), middle=True)

                s_model.g = query_subgraph
                for layer in s_model.gat_layers:
                    layer.g = query_subgraph
                s_logits_query, s_middlefeats_query = s_model(query_feats.float(), middle=True)

                t_model.g = support_subgraph
                for layer in t_model.gat_layers:
                    layer.g = support_subgraph
                _, t_middlefeats_support = t_model(support_feats.float(), middle=True)

                t_model.g = query_subgraph
                for layer in t_model.gat_layers:
                    layer.g = query_subgraph
                _, t_middlefeats_query = t_model(query_feats.float(), middle=True)

                #取GNN最后一层求LSP,作为蒸馏对象
                t_lsp_support = auxiliary_model['local_model']['model'](support_subgraph, t_middlefeats_support[-1])
                s_lsp_support = auxiliary_model['local_model']['model'](support_subgraph, s_middlefeats_support[-1])
                t_lsp_query = auxiliary_model['local_model']['model'](query_subgraph, t_middlefeats_query[-1])
                s_lsp_query = auxiliary_model['local_model']['model'](query_subgraph, s_middlefeats_query[-1])

                #pseudo_LSP_from_t_support即t_lsp_support(就是hard_pseudo_label = torch.argmax(t_logits_support.detach(), dim=-1))
                
                #pseudo_LSP_from_t_support = t_lsp_support
                
                #在query上找t0_lsp和s_lsp,并用graph_KL计算他们的梯度,原版是找s和true lable的距离,这里再训练一个教师t0
                #把他的label作为true label
                label_loss_old = loss_fcn(s_logits_query, query_labels.float())

                "Meta-Distill第一步,创建并更新s_copy_model,根据support上的t_lsp和s_lsp表现区别"
                s_copy_model = copy.deepcopy(s_model)
                s_copy_optimizer = optimizer_list[model_id]
                s_copy_lsp_loss_list = []
                s_copy_model.train()
                s_copy_lsp_support = auxiliary_model['local_model']['model'](support_subgraph, s_middlefeats_support[-1])
                #是否需要对其进行梯度裁剪?
                #torch.nn.utils.clip_grad_norm_(s_copy_model.parameters(), args.max_grad_nrom)
                
                s_copy_optimizer.zero_grad()
                s_copy_lsp_support_loss = graph_KLDiv(support_subgraph, t_lsp_support.detach(), s_copy_lsp_support, reduce='mean')
                #s_copy_lsp_support_loss.backward(retain_graph=True)#?????一定要这样吗，有没有其他影响????
                s_copy_lsp_support_loss.backward(retain_graph=True)
                #s_copy_optimizer.step() step要一起放在最后面？？？？
                s_copy_lsp_loss_list.append(s_copy_lsp_support_loss.item())
                #是否需要将其梯度归零？？需要的,清零下次循环的时候备用，step的时候完成了更新
                

                "Meta-Distill第二步, 根据pseudo label化简结果公式更新教师模型"
                #new-view版第二步按照原版设定，找s_copy和true label的距离,不涉及lsp
                with torch.no_grad():
                    s_copy_logits_query, s_copy_middlefeats_query = s_copy_model(query_feats.float(), middle=True)
                    t_model.g = support_subgraph
                    for layer in t_model.gat_layers:
                        layer.g = support_subgraph
                    t_logits_support, t_middlefeats_support = t_model(support_feats.float(), middle=True) 
                #在query上找t0_lsp和s_lsp,并用graph_KL计算他们的梯度,原版是找s_copy和true lable的距离
                #先求s_copy在query上的结果
                label_loss_new = loss_fcn(s_logits_query, query_labels.float())
                dot_product = label_loss_old - label_loss_new
                #利用化简结果更新教师
                #t_loss = dot_product * F.kl_div(t_lsp_support, t_lsp_support) ?????
                #pseudo_LSP_from_t_support即t_lsp_support(就是hard_pseudo_label = torch.argmax(t_logits_support.detach(), dim=-1))
                t_optimizer.zero_grad()
                pseudo_label_from_t_support = torch.argmax(t_logits_support.detach(), dim=-1)
                t_loss = dot_product * F.cross_entropy(support_labels,pseudo_label_from_t_support)
                '''可否做成t_loss = t_lsp_loss + t_softlabel_loss形式
                   t_softlabel_loss = softlabel_dot_product * F.cross_entropy(t_support,pseudo_Label_from_t_support)
                   t_lsp_loss = lsp_dot_product * F.cross_entropy(t_support,pseudo_Label_from_t_support)
                   t_loss = (α*lsp_dot_product + β*softlabel_dot_product) * F.cross_entropy(t_support,pseudo_Label_from_t_support)
                '''
                t_loss.backward(retain_graph=True)
                #t_optimizer.step() step要一起放在最后面???
                
                "Meta-Distill第三步, 根据新t更新学生s(把第一步用在s上),获取最终的lsp_loss"
                #获取更新后的教师LSP表征(on support dataset)
                t_model.g = support_subgraph
                for layer in t_model.gat_layers:
                    layer.g = support_subgraph

                _, t_middlefeats_support = t_model(support_feats.float(), middle=True)
                _, t_middlefeats_support = t_model(support_feats.float(), middle=True)
                t_lsp_support = auxiliary_model['local_model']['model'](support_subgraph, t_middlefeats_support[-1])

                #lsp_loss = s_lsp_support_loss 是最终的学生的lsp_loss
                lsp_loss = graph_KLDiv(support_subgraph, t_lsp_support.detach(), s_lsp_support, reduce='mean')
                
                "还需加上在学生在整个train上的实际分类表现,获取label_loss"
                try:
                    train_batch = train_iter.__next__()
                    train_subgraph, train_feats, train_labels = train_batch

                except:
                    train_iter = iter(train_dataloader)
                    train_batch = train_iter.__next__()
                    train_subgraph, train_feats, train_labels = train_batch
                
                train_feats = train_feats.to(device)
                train_labels = train_labels.to(device)
                train_subgraph = train_subgraph.to(device)

                s_model.g = train_subgraph
                for layer in s_model.gat_layers:
                    layer.g = train_subgraph
                
                s_logits_train, s_middlefeats_train = s_model(train_feats.float(), middle=True)

                label_loss = loss_fcn(s_logits_train, train_labels.float())

                s_optimizer.zero_grad()

                "合成最终的loss"
                loss = label_loss + lsp_loss

                loss.backward(retain_graph=True)
                
                s_copy_optimizer.step()
                t_optimizer.step()
                s_optimizer.step()
                
                loss_list.append(loss.item())
                s_lsp_loss_list.append(lsp_loss.item())
                
                #t_optimizer.zero_grad()

            #一下部分是正常训练框架
            loss_data = np.array(loss_list).mean()
            lsp_loss_data = np.array(s_lsp_loss_list).mean()

            with open(log_txt, 'a+') as f:
                f.write(f"Epoch {epoch:05d} | ModelID: {model_id:02d}|Loss: {loss_data:.4f}| Time: {time.time()-t0:.4f}s\n")
            print(f"Epoch {epoch:05d} | ModelID: {model_id:02d}|Loss: {loss_data:.4f}| Time: {time.time()-t0:.4f}s")
            if epoch % 10 == 0:
                score = evaluate_model(valid_dataloader, train_dataloader, device, s_model, loss_fcn)
                if score > best_score[model_id] or loss_data < best_loss[model_id]:
                    best_score[model_id] = score
                    best_loss[model_id] = loss_data
                    test_score[model_id] = test_model(test_dataloader, s_model, device, loss_fcn)
                    with open(log_txt, 'a+') as f:
                        f.write('f1 score on testset:{}\n'.format(test_score))
                    print("f1 score on testset:" ,test_score)

    with open(log_txt, 'a+') as f:
        f.write('final f1 score on testset:{}\n'.format(test_score))
    print("final f1 score on testset:" ,test_score)




def main(args):
    device = torch.device("cpu") if args.gpu<0 else torch.device("cuda:" + str(args.gpu))
    data, data_info = get_data_loader(args)
    model_dict = collect_model(args, data_info)
    print(f"number of parameter for student model: {parameters(model_dict['s_model']['model'][0])}")
    print("############ train student models#############")
    train_student(args, model_dict, data, device)



if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='GAT')
    parser.add_argument("--gpu", type=int, default=0,
                        help="which GPU to use. Set -1 to use CPU.")
    parser.add_argument("--residual", action="store_true", default=True,
                        help="use residual connection")
    parser.add_argument("--in-drop", type=float, default=0,
                        help="input feature dropout")
    parser.add_argument("--attn-drop", type=float, default=0,
                        help="attention dropout")
    parser.add_argument('--alpha', type=float, default=0.2,
                        help="the negative slop of leaky relu")
    parser.add_argument('--batch-size', type=int, default=2,
                        help="batch size used for training, validation and test")
    parser.add_argument('--model_num',type = int ,default=3)
    parser.add_argument('--model_name',type = str ,default='GAT')

    parser.add_argument('--a',type=float,default=1)
    parser.add_argument("--lr", type=float, default=0.001,
                        help="learning rate")
    parser.add_argument('--weight-decay', type=float, default=0,
                        help="weight decay")

    parser.add_argument("--s-epochs", type=int, default=300,
                        help="number of training epochs")
    parser.add_argument("--s-num-heads", type=int, default=3,
                        help="number of hidden attention heads")
    parser.add_argument("--s-num-out-heads", type=int, default=3,
                        help="number of output attention heads")
    parser.add_argument("--s-num-layers", type=int, default=4,
                        help="number of hidden layers")
    parser.add_argument("--s-num-hidden", type=int, default=64,
                        help="number of hidden units")
   
    parser.add_argument("--strategy", type=str, default='alignahead')
    parser.add_argument("--warmup-epoch", type=int, default=600,
                        help="steps to warmup")
    parser.add_argument('--seed', type=int, default=100,
                        help="seed")


    args = parser.parse_args()
    print(args)

    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    
    
    log_txt = 'result/'+ \
          'model_num' + '_' +  str(args.model_num) + '_'+\
          's_layers' + '_' +  str(args.s_num_layers) + '_'+\
          'model' + '_' +  str(args.model_name) + '_'+\
          'strategy' + '_' +  str(args.strategy) + '_'+\
          'seed'+ str(args.seed) +'.txt'   
    main(args)
                


                

                

                


            

                








        
