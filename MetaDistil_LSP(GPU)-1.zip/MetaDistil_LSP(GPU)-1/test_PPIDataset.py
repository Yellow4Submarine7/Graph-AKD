import os
import copy 
import numpy as np
import torch
import torch.nn.functional as F
import dgl.function as fn
from torch.nn import init
import dgl
import argparse
from gat import GAT
from torch.utils.data import DataLoader
from dgl.data.ppi import LegacyPPIDataset as PPIDataset

train_dataset = PPIDataset(mode='train')
# valid_dataset = PPIDataset(mode='valid')
#test_dataset = PPIDataset(mode='test')
# train_support_dataset = PPIDataset(mode='train_support')
# train_query_dataset = PPIDataset(mode='train_query')
